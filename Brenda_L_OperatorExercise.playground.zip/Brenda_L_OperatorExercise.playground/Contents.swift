// Variables
var number1 = 1
var number2 = 2
var number3 = 3
var number4 = 4
var number5 = 5
var number6 = 6
// Operators
2 + 2
2 - 2
2 * 2
// Results
print(number2 + number6)
print(number5 - number1)
print(number6 * number3)
print(number4 / number2)
